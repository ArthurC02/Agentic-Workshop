from __future__ import annotations

import subprocess
from pathlib import Path

from .attestations import verify_git_signed_commit
from .policy import review_governance, review_mode

HOOK_MARKER = "domain-memory-pre-push"
EMPTY_SHA = "0" * 40


def inside_repo(path: Path, repo_root: Path) -> str:
    resolved = path.resolve()
    try:
        return resolved.relative_to(repo_root.resolve()).as_posix()
    except ValueError:
        return resolved.as_posix()


def hooks_dir(repo_root: Path) -> Path:
    result = subprocess.run(
        ["git", "-C", str(repo_root), "rev-parse", "--git-path", "hooks"],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        return repo_root / ".git" / "hooks"
    reported = Path(result.stdout.strip())
    return reported if reported.is_absolute() else repo_root / reported


def governance_readiness(registry_root: Path, repo_root: Path) -> dict[str, object]:
    mode = review_mode(registry_root)
    if mode == "local-draft-only":
        return {"status": "working-memory", "blocks": []}
    governance = review_governance(registry_root)
    blocks = []
    if governance["verifier"] == "git-signed-commit":
        if not governance["authorized_signers"]:
            blocks.append("no authorized Git signers")
        hook = hooks_dir(repo_root) / "pre-push"
        if not hook.is_file() or HOOK_MARKER not in hook.read_text(encoding="utf-8"):
            blocks.append("Git HITL pre-push hook is not installed on this machine")
    return {"status": "needs-setup" if blocks else "ready", "blocks": blocks}


def verify_git_governance(registry_root: Path, repo_root: Path, commit: str) -> list[str]:
    governance = review_governance(registry_root)
    if governance["verifier"] != "git-signed-commit":
        return ["Domain Memory policy does not select git-signed-commit"]
    return verify_git_signed_commit(
        {"commit": commit}, repo_root, registry_root, governance["authorized_signers"]
    )


def install_pre_push_hook(registry_root: Path, repo_root: Path, script: Path) -> Path:
    hooks = hooks_dir(repo_root)
    if not hooks.is_dir():
        raise ValueError(f"Git hooks require an existing hooks directory at {hooks}")
    relative = registry_root.resolve().relative_to(repo_root.resolve()).as_posix()
    hook = hooks / "pre-push"
    backup = hooks / "pre-push.domain-memory-existing"
    if hook.exists() and HOOK_MARKER not in hook.read_text(encoding="utf-8"):
        if backup.exists():
            raise ValueError("existing Domain Memory pre-push hook backup already exists")
        hook.replace(backup)
    script_text = (
        "#!/bin/sh\n"
        f"# {HOOK_MARKER}\n"
        f"tool='{inside_repo(script, repo_root)}'\n"
        f"memory='{relative}'\n"
        f"existing='{inside_repo(backup, repo_root)}'\n"
        "refs=$(cat)\n"
        "if [ -x \"$existing\" ]; then\n"
        "  printf '%s\\n' \"$refs\" | \"$existing\" \"$@\" || exit 1\n"
        "fi\n"
        "printf '%s\\n' \"$refs\" | while read local_ref local_sha remote_ref remote_sha; do\n"
        "  test -n \"$local_sha\" || continue\n"
        f"  test \"$local_sha\" = \"{EMPTY_SHA}\" && continue\n"
        "  range=\"$local_sha --not --remotes\"\n"
        f"  test \"$remote_sha\" = \"{EMPTY_SHA}\" || range=$remote_sha..$local_sha\n"
        "  for commit in $(git rev-list $range -- \"$memory\"); do\n"
        "    python \"$tool\" verify-git-governance --registry-root \"$memory\" --repo-root . --commit \"$commit\" || exit 1\n"
        "  done\n"
        "done || exit 1\n"
    )
    hook.write_text(script_text, encoding="utf-8", newline="\n")
    hook.chmod(hook.stat().st_mode | 0o111)
    return hook
