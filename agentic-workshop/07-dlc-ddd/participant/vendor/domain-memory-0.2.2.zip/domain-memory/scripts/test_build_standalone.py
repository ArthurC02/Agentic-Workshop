from __future__ import annotations

import re
import tempfile
import unittest
from pathlib import Path

from build_standalone import build


class BuildStandaloneTest(unittest.TestCase):
    def test_bundle_contains_one_skill_and_all_relative_resources(self) -> None:
        plugin = Path(__file__).parents[1]
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / "domain-memory-read"
            build(plugin, "domain-memory-read", output)
            skill = (output / "SKILL.md").read_text(encoding="utf-8")
            self.assertIn("(references/script-api.md)", skill)
            self.assertNotIn("../../references/", skill)
            self.assertTrue((output / "references/script-api.md").is_file())
            self.assertTrue(
                (output / "templates/domain-change-proposal.json").is_file()
            )
            self.assertTrue((output / "scripts/registry_tools.py").is_file())
            self.assertFalse((output / "scripts/test_domain_registry.py").exists())

    def test_bundle_carries_the_entry_point_for_a_host_without_skills(self) -> None:
        plugin = Path(__file__).parents[1]
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / "domain-memory-read"
            build(plugin, "domain-memory-read", output)
            entry = (output / "AGENTS.md").read_text(encoding="utf-8")
            self.assertIn("python3 scripts/registry_tools.py", entry)
            links = re.findall(r"\]\(([^)]+)\)", entry)
            self.assertIn("references/script-api.md", links)
            for link in links:
                self.assertTrue((output / link).is_file(), link)

    def test_every_capability_bundle_carries_what_its_page_links_to(self) -> None:
        plugin = Path(__file__).parents[1]
        capabilities = sorted(p.name for p in (plugin / "skills").iterdir())
        self.assertIn("domain-memory-implementation-hygiene", capabilities)
        for capability in capabilities:
            with self.subTest(capability), tempfile.TemporaryDirectory() as temporary:
                output = Path(temporary) / capability
                build(plugin, capability, output)
                page = (output / "SKILL.md").read_text(encoding="utf-8")
                links = re.findall(r"\]\(([^)#]+)\)", page)
                self.assertTrue(links)
                for link in links:
                    self.assertTrue((output / link).is_file(), link)

    def test_the_code_rules_read_the_same_on_the_entry_and_the_hygiene_page(self) -> None:
        plugin = Path(__file__).parents[1]

        def code_rules(page: Path) -> list[str]:
            text = page.read_text(encoding="utf-8")
            section = text.split("## When you are the one writing the code", 1)[1]
            section = section.split("\n## ", 1)[0]
            return re.findall(r"^\d+\. .+$", section, re.MULTILINE)

        entry = code_rules(plugin / "AGENTS.md")
        hygiene = code_rules(
            plugin / "skills/domain-memory-implementation-hygiene/SKILL.md"
        )
        self.assertEqual(len(entry), 6)
        self.assertEqual(entry, hygiene)

    def test_unknown_skill_does_not_create_output(self) -> None:
        plugin = Path(__file__).parents[1]
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / "missing"
            with self.assertRaises(ValueError):
                build(plugin, "missing", output)
            self.assertFalse(output.exists())


if __name__ == "__main__":
    unittest.main()
