# File-backed Domain Memory API

The `domain-memory` executable, chosen per platform as [running the commands](../AGENTS.md#running-the-commands) says, is the stable command entry point. It implements the read, query, and controlled update capability that a remote Domain Memory API would provide, using files in the local repository.

The commands fall into two groups, which `--help` without a command lists too. Everyday commands are the seven-step workflow, harvest, review and reading. Advanced commands set up, govern, recover and measure: rarely run, still needed. Each command has one section: its synopsis, then what it guarantees and how it refuses.

Everyday: [`readiness`](#readiness), [`verify-sources`](#verify-sources), [`verify-evidence`](#verify-evidence), [`verify-audit`](#verify-audit), [`reconcile-audit`](#reconcile-audit), [`refresh-indexes`](#refresh-indexes), [`probe`](#probe), [`validate`](#validate), [`coverage`](#coverage), [`cite`](#cite), [`get-record`](#get-record), [`brief`](#brief), [`dependents`](#dependents), [`resolve-terms`](#resolve-terms), [`get-context`](#get-context), [`analyze-boundary`](#analyze-boundary), [`boundary-impact`](#boundary-impact), [`lookup`](#lookup), [`upsert-candidate`](#upsert-candidate), [`harvest`](#harvest), [`discard-harvest`](#discard-harvest), [`retract-candidate`](#retract-candidate), [`promote-candidate`](#promote-candidate), [`init-change-package`](#init-change-package), [`validate-change-package`](#validate-change-package), [`recite`](#recite), [`relocate-evidence`](#relocate-evidence), [`submit-proposal`](#submit-proposal), [`list-proposals`](#list-proposals), [`supersede-proposal`](#supersede-proposal), [`record-approval`](#record-approval), [`record-test-result`](#record-test-result), [`ship-package`](#ship-package), [`verify-proposal`](#verify-proposal), [`rebase-proposal`](#rebase-proposal), [`quality-gates`](#quality-gates), [`counterfactual`](#counterfactual).

Advanced: [`discover-sources`](#discover-sources), [`init-domain-memory`](#init-domain-memory), [`refine-sources`](#refine-sources), [`recover-registry-update`](#recover-registry-update), [`export`](#export), [`change-coupling`](#change-coupling), [`compare-registry`](#compare-registry), [`confirm-sources`](#confirm-sources), [`harvest-candidates`](#harvest-candidates), [`redraft-proposal`](#redraft-proposal), [`audit-attestations`](#audit-attestations), [`governance-readiness`](#governance-readiness), [`init-signing-key`](#init-signing-key), [`amend-policy`](#amend-policy), [`install-git-hitl-hook`](#install-git-hitl-hook), [`install-pre-commit-hook`](#install-pre-commit-hook), [`verify-git-governance`](#verify-git-governance), [`validate-policy`](#validate-policy), [`verify-scm-attestation`](#verify-scm-attestation), [`demote-local-reviews`](#demote-local-reviews), [`refresh-sources`](#refresh-sources), [`refresh-listing`](#refresh-listing), [`scan-secrets`](#scan-secrets), [`mcp-serve`](#mcp-serve), [`validate-contract`](#validate-contract).

Then [preparing the approval authority](#preparing-the-approval-authority), [output and refusals](#output-and-refusals) and [the shape of an update](#the-shape-of-an-update).

## Everyday commands

### `readiness`

*Assess project readiness.*

`readiness --repo-root <repo> [--registry-root <path>]`

Reports the posture described in [readiness](readiness.md). It is read-only and never promotes a fact or selects a source corpus. Without `--registry-root` it looks for the Domain Memories the repository holds (the paths git lists or would add that carry a `registry/` holding `index.md`, or a `source-map.json` whose `format` is `domain-source-map/v1`; a bare `registry/` directory or an unrelated file of that name is not one): one is assessed as if named, with `registry_root` set and a `NOTE:` on stderr saying so; several are listed in `domain_memories` with a `NOTE:` asking for `--registry-root`, and none is assessed; when git cannot list them, because it cannot start or the directory is not a repository, `domain_memories` is null, none is assessed, and the `NOTE:` gives git's reason and asks for `--registry-root`. With a Registry whose policy names a verifier, `governance_candidates` reports the `configured_verifier` and `configured_trigger` instead of recommending one. With a usable Registry it adds a `listing` signal, `current` or `drifted` with `discovered_but_gone` and `discovered_but_unlisted` as `verify-sources` reports them, and on drift prints the same `NOTE:` with the `refresh-listing` to run on stderr; the listing is never a block.

### `verify-sources`

*Verify selected sources.*

`verify-sources --repo-root <repo> --source-map <path> [--policy <path>]`

Separates the selection moving from its content changing, and, when supplied, rechecks policy limits. A file appearing, disappearing or being renamed under a selected path means the corpus is no longer the one a developer confirmed, so it reports `stale` in `changed_sources`. An edit inside a file that is still there is reported in `content_changed` and leaves the map current: whether a record's evidence survived that edit is a per-citation question `verify-evidence` answers exactly. A snapshot without a listing can only compare file counts, so a rename inside a directory it selects reaches the citation check instead. Once the repository tracks any file, snapshots, the discovery listing and `git_state` take tracked files only, so an untracked scratch file never reaches a committed map nor makes another clone's map stale; a repository that tracks nothing yet is read from its working tree. The map also keeps the discovery listing it was selected from, `source_groups`, which only tags citations with a source kind and is never evidence; `discovered_but_gone` names its entries discovery no longer finds today, a deleted file or a path discovery no longer places, which is exactly what `refresh-listing` would drop, and `discovered_but_unlisted` names the paths discovery would place in a group today that the map does not list. When either is non-empty, stderr carries one `NOTE:` with both counts, and a map that would be `current` reports `discovery_drifted` instead, still with exit 0 and a `NOTE:` that opens by saying the selected sources are current and the check passes, because the listing is not evidence and a new file must not fail a gate; `stale` is never replaced, and the hash fields keep their own verdict. When `content_changed` is non-empty the NOTE also says how many selected sources changed inside and that `verify-evidence` checks the citations, because a confirmation covers which paths are sources, not their text. The NOTE of a `discovery_drifted` map points at `refresh-listing`, which needs no confirmation; the NOTE of a `stale` map points at `refresh-sources` then `confirm-sources`.

### `verify-evidence`

*Verify citations.*

`verify-evidence --registry-root <path> --repo-root <repo> [--path <file>]... [--strict] [--staged] [--package-root <package>]`

Detects missing, malformed, and changed structured evidence citations, each named by its record's asset and id and carrying the `cited_lines` it records. Statuses: `shifted` with the new `lines` when the excerpt is unchanged but moved within its file, which does not fail; `stale` when the cited lines changed since their digest was recorded; `unhashed` when no digest was ever recorded. `--path`, repeated, checks only the citations of those files and adds `paths`, each requested file with its number of citations and whether it `exists`, so a mistyped path is not read as an uncited file. `--strict` also fails on a `shifted` citation. `--staged` reads each cited file as the Git index holds it instead of from the disk, so it checks what the next commit will contain; a file the index does not hold as a regular file at stage 0 is `missing` and `exists` is false, and an index Git cannot read is refused. `--package-root` checks the Registry as that Change Package's `registry_updates` would leave it, an upsert replacing or adding the record and a remove dropping it, so a package that re-cites changed lines can prove its citations current before it is applied. A failing run names the failing counts on stderr; with `--staged` it first prints one line per failing citation, `<asset>/<id>: <path>:<start>-<end> changed; check that its statement still holds; recite only if it does, otherwise amend it` for a `stale` one and `<asset>/<id>: <path> is not in this commit; relocate-evidence if it moved, otherwise amend or retire the record` for a `missing` one, which is also what a cited file deleted or renamed in the index becomes. When to run it, and what each status asks of you: [Evidence rules](evidence-rules.md).

### `verify-audit`

*Verify audit trail.*

`verify-audit --registry-root <path> [--changes-root <dir>] [--against <git revision>]`

Validates the local append-only hash-linked log and its small head manifest. Each event names the event or events it was appended on in `previous_event_sha256` and carries its height in `sequence`, so the log is a DAG as a git history is: a clone's events stay valid after a merge brings another clone's events in, every named parent must be present, every digest must match, no event may repeat, and the manifest must name the `heads`, the events nothing was appended on (`head_sha256` when there is one, null while there are several). It is tamper-evident, not an external immutable log, so dropping the newest events and rewriting the manifest to match goes unseen by the chain alone. `--changes-root` also requires every applied proposal under the directory, including one superseded after it was applied, to have its `apply-approved-updates` event. `--against` compares with the manifest committed at that revision, the anchor a signed commit gives: the log must still hold at least that many events and every head the committed manifest names, and a revision with no committed manifest anchors nothing and fails. A root without a Registry is `invalid`, not an empty valid chain. A log that still holds git conflict markers is `invalid` with `conflict markers at event N; run reconcile-audit --registry-root <path>`.

### `reconcile-audit`

*Reconcile audit trail.*

`reconcile-audit --registry-root <path>`

Repairs the log after a git merge brought two clones' events together: it drops git conflict-marker lines from `audit/events.jsonl`, keeps each event once, rewrites the file in height order, rewrites `audit/manifest.json` from the events, and, when the log has several heads, appends one `reconcile-audit` event naming them in `joined`, so the log has one head again. A log that needs nothing prints `written` false. It refuses a log whose events do not verify as a DAG, so a removed or rewritten event is not papered over. Run it when `git merge` or `git pull` reports a conflict under `audit/`, then `git add` both files and continue the merge; run it before any audited command on a log that has several heads. After a merge the whole procedure is `reconcile-audit`, `refresh-indexes`, then `validate`, which names any file still holding conflict markers.

### `refresh-indexes`

*Rebuild concept indexes.*

`refresh-indexes --registry-root <path>`

Rewrites `registry/index.md` and each `registry/<asset>/index.md` from the concept files beside them, never from the index a merge left behind, and prints the indexes it rewrote in `refreshed`; a current set prints an empty list. Run it after a merge touched an index, or whenever `validate` says an index does not list the records beside it.

### `probe`

*Report Registry health.*

`probe --repo-root <repo> --registry-root <path> [--policy <path>]`

Says whether a Domain Memory is present, current, and how its sources were established; a current selection whose files changed inside is reported with their count and `verify-evidence` named, and one whose discovery listing drifted is reported as `verify-sources` reports it, still with exit 0. When the root has no source map but its parent does, it names the likely root instead of reporting nothing. It reports posture, not whether a record is true. It exits 0 when the Domain Memory is `current`, 2 when it is `absent` (no source map at the root, with or without a likely root named), and 1 for any other status: `stale`, `invalid` or `unverified`.

### `validate`

*Validate the Registry.*

`validate --registry-root <path> [--repo-root <repo>] [--require-reviewed]`

Checks file shape, asset formats, status values, IDs, and references. A file under `registry/`, under `changes/` or a JSON file at the root that holds git conflict markers is refused first, every such file named with the line, and nothing else is reported until the merge is resolved. The `domain-memory-policy.json` beside the Registry, when there is one, is checked next as `validate-policy` checks it, and a policy it refuses, or one that is not JSON, is likewise reported alone, since the policy decides what the rest of the check requires; an asset index that does not list the concept files beside it is refused with `refresh-indexes` named. `--require-reviewed` additionally refuses a Registry whose records are candidates or whose policy cannot establish a reviewed record at all. A NOTE on stderr names each approved Change Package under the Registry's `changes/` directory that is not applied yet, and says how to retire one that cannot be, and another each superseded package whose `superseded_by` no package there carries. With `--repo-root` it also refuses a reviewed Context whose `implementation_path` lies over no file in the repository, by the same test `boundary-impact` uses to map a file to its Context, so a path left behind by a move is caught before an impact reads as clean; a candidate's is a NOTE, since a candidate may name code to come, and `ship-package` refuses to review it until the code is there.

### `coverage`

*Report modelling gaps.*

`coverage --registry-root <path> [--changes-root <dir>] [--repo-root <repo>]`

Lists Contexts holding no vocabulary, aggregate, rule, contract, or event, separating an examined absence from an unexamined one, and names every reviewed record that carries no evidence or cites outside the selected sources. `rules_by_context` gives every Context its `reviewed_rules` and `candidate_rules`, fewest reviewed first, so the Contexts a harvest should start from come first; a Context a rule names but the Registry lacks is listed too. With Change Packages, from `--changes-root` or the Registry's `changes/` directory, each row also lists the reviewed rules by proof: `proven` when a package that reviewed it covers it with a test obligation, `unproven` when none does, and `unknown` when a package that reviewed it since is not there to read; without them a NOTE says the proof was not counted. `rule_totals` counts each rule once, however many Contexts it names: `reviewed_rules`, `candidate_rules`, `contexts_without_reviewed_rules`, and, with Change Packages, `proven`, `unproven` and `unknown`. `--repo-root` is accepted so a script can pass the same flags everywhere, and is not used.

### `cite`

*Build an evidence citation.*

`cite --repo-root <repo> --path <file> (--lines <start>-<end> | --function <name>) [--registry-root <path>] [--show]`

Produces the digest-backed citation object a record's `evidence` requires; `--function` cites the whole body of the one function of that name in a Go, Python, TypeScript, JavaScript, Java, Kotlin or Rust file (a Go `func`, a Python `def`, a `function`, an arrow function bound with `const`, `let` or `var` (its parameters on the same line as the `=` or on the next), a class method, a Java method or constructor, a Kotlin `fun`, a Rust `fn`; outside Python a block body runs to the brace that closes the one the signature opens, an arrow function's expression body to the semicolon that ends its statement, and a Kotlin expression body to the end of its line, each read past strings, template literals, comments and nested brackets; a call that starts a line is not a definition, whatever follows it, and any other file type is cited with `--lines`), such as the test that proves a rule (a name the file does not define in one of those forms is refused with the forms named, the file and line that defines it among the repository's files of the same language, or every such file when several do, and `--lines` for a definition of another form), and refuses a name defined twice or not at all; pass the object whole, and the Registry keeps only its path, lines and `excerpt_sha256`. `--show` prints the first and last cited lines on stderr, so a range that starts mid-function or points at other code is seen before it is stored. When the cited text also occurs elsewhere in the file, it prints a NOTE on stderr naming where, because such a citation cannot be told apart after the next edit; widen it to lines that occur once.

### `get-record`

*Retrieve a record.*

`get-record --asset <asset> --id <id> [--changes-root <dir>]`

Returns the exact stored record or fails, naming up to three ids that start with or resemble the one given. A reviewed rule or contract also carries `proven_by`, read from `--changes-root` or, without it, the Registry's own `changes/` directory when there is one: each test obligation whose source or `also_covers` names it, from the most recent Change Package that reviewed it with such an obligation, so a later re-citation, which carries none, does not hide the proof (a NOTE names it), with the obligation's `check` and the `working_directory` its passing run was recorded in (`.` for the repository root). A NOTE says when the record was not reviewed through a package, or when that package is not under the directory, so the proof is unknown rather than absent.

### `brief`

*Brief a change or a record.*

`brief --registry-root <root> --repo-root <repo> (--base <git revision> | --asset <asset> --id <id>) [--markdown]`

Read-only. One document composed from `boundary-impact`, `dependents`, `get-context --summary` and `verify-evidence`. With `--base`: the verdict; each Context touched with its changed files and summarized model; each record of any asset whose cited lines the change touches, evidence and test citations alike, with its dependents, for a collaboration record whether its cited excerpt changed, and for a rule `check` and `cwd`: the test obligation that proves it in the applied Change Package under `<root>/changes`, or null when no package there proves it; `registry_changes`: each record the Registry gained, amended or lost between the base and the working tree (`change` is `added`, `amended` or `removed`), with its status, summary and `through`, the last proposal whose apply reviewed it, or null; the citation verification of the changed files; the cited files outside every Context, each with `cited_as`, the source kind of that path in the source map or null without one; `unmapped_files`, every changed file outside every Context and outside the Domain Memory, which the brief therefore does not cover; the evidence's `citations`, each one that is not `current` with its asset, id, path, status and, when shifted, the lines it sits at now; `source_map`: `{"changed": false}` when `<root>/source-map.json` is the same at the base and in the working tree, otherwise `changed`, `confirmed_by`, `confirmation` and the counts `discovered_added` and `discovered_removed`; and `attention`, one line per thing a reviewer must act on. An unknown base is refused as `boundary-impact` refuses it. With `--asset --id`: the record, its Contexts, the records that reach it through relations, the verification of what it cites, and `attention`. `--markdown` renders the same brief for a pull request or a review note; the default is JSON. In a change's Markdown, each Context lists the records that cite a changed file and only counts its others, which `get-context` lists.

`brief` is the one document to read before reviewing a change or touching a record.

- A Registry absent at the base lists every record as added in `registry_changes`.
- The `confirmation` of `source_map` is its `selection_status` now, or `removed`.
- `attention` holds one line per asset and reviewing proposal of the records the range changed.
- It holds one line when the source map changed, naming who confirmed it or that it is not confirmed.
- It holds one line per cited file outside every Context, except a file whose kind is `tests`, which only proves a rule and is listed without one.
- It holds one line naming the changed files outside every Context, grouped by directory, and one more when one of them sits under a `contracts/` directory, since a contract change usually crosses Contexts.

### `dependents`

*Follow a record's relations.*

`dependents --asset <asset> --id <id>`

Read-only. Walks every relation from the record in both directions and lists each record reached with its `asset`, `status`, one-line `summary`, the `through` field that joined it and its `depth`. A Context is reached but not crossed, so the walk stays within the record's own coupling instead of spilling over everything in the Context. Before changing a record, this is what else the change may touch.

### `resolve-terms`

*Resolve vocabulary.*

`resolve-terms --query <text> [--query <text> ...] [--context <id>] [--with-mentions]`

Answers each query in order in one list, each match naming the `query` it answers; the result limit applies per query. Matches a Vocabulary record when its name, id or a synonym appears in the query, or the query appears in one of them or in its definition; a whole sentence is a valid query. Each match carries `match_kind` (`name`, `synonym` or `definition`), listed in that order. Only a `name` match grounds the term; a `synonym` match means the query used a name to avoid, and a `definition` match means no term has that name. When no term matches a query, or always with `--with-mentions`, it lists after the terms the reviewed records whose text holds every word of it, in any order and in another form of the word: any text field, any list of text such as `examples`, and the record's id read word by word, those whose id, name, responsibility, statement, definition or description mentions it first, rules and contracts before other assets, each record once with `match_kind: "mentioned"`, `status: "reviewed"`, the `asset`, `id`, the `contexts` it names, a `summary` (the first sentence of its statement, definition, description or responsibility) and every `fields` entry that mentions it: the concept is talked about but has no term yet, which is a gap to record, not proof of who owns it. An empty answer means no reviewed record mentions it either, which still does not prove absence. A NOTE says when the result limit cut a query's matches, and when a matching term hid rules or contracts that mention the query.

### `get-context`

*Retrieve a Context model.*

`get-context --id <id> [--summary]`

Returns the Context with its vocabulary, aggregates, rules, capabilities and value objects, the contracts, interactions and events it produces or consumes, and `rules_bound_through_collaborations`: rules of other Contexts that cite a file one of this Context's interactions or contracts cites, such as the purge rule of the Context that runs this one's purge step, each with the collaborations it shares a file with. `--summary` gives each record as its id, status and one line, without evidence, for reading before a change.

### `analyze-boundary`

*Inspect a boundary.*

`analyze-boundary --source-context <id> --target-context <id>`

Lists what is registered between the two Contexts in each direction, so a call one way and a permission the other way are never read as one relation. `source_depends_on_target` holds the interactions and contracts the target produces for the source, the events of the target the source consumes, and the dependency policies from the source to the target; `target_depends_on_source` holds the same the other way round. `status` is `known` when an interaction, contract or consumed event connects them in either direction, `policy_only` when only a dependency policy does, which permits the dependency but records no collaboration, and `no_registered_collaboration` otherwise.

### `boundary-impact`

*Find boundaries a change touches.*

`boundary-impact --registry-root <root> --repo-root <repo> --base <git revision>`

Read-only. Lists the files changed since `base`, tracked or untracked, by the Context whose `implementation_path` holds them, matched as consecutive directory names anywhere in the path. For each pair of Contexts touched together it lists the registered interactions, contracts and dependency policies between them, and it lists the interactions, contracts and dependency policies whose evidence cites a changed file at lines that no longer match; a citation whose lines only moved within the file is not changed evidence. `boundary_evidence_touched` lists those whose cited lines, as cited now, overlap a line the change added or rewrote, or lie in a new untracked file, with each `touched_evidence` as `path:start-end`: the change touches what the record cites even when the citation still matches. `verdict` is `unregistered-co-change`, `boundary-evidence-changed`, `registered-co-change`, `no-cross-context-change`, or `unknown` when no Context records an `implementation_path`. `outside_every_context` lists the changed files no Context owns, such as a composition root, which the verdict does not cover; `mapped_files` beside `changed_files` says how much of the change the verdict speaks for, and `cited_outside_contexts` names each of those files that a Registry record cites, such as a contract specification or a rule's proving test, with the records citing it. Changing together is a prompt to check, not proof of a dependency.

### `lookup`

*Search an asset.*

`lookup --asset <asset> --query <text>`

Deterministic file-backed text matching. A record holding the query as written comes first, ordered by where: an id or name that is the query, then an id or name that holds it, then any other text; otherwise the records holding every word of it, in any order and in another form of the word (`concurrent` finds `concurrency`, `licensing` finds `license`, `takedown` finds `taken down`, `take-down` and `TakedownAt`); otherwise the records holding the most of its words, with a NOTE saying so. Words such as `after`, `the`, `when`, `who` or `can` do not count as shared, and neither, in this last step, does a word held by more than a quarter of the records and at least three of them, such as `skill` in a Registry about skills: when only such words are shared, nothing is listed and a NOTE says so, since that list would be noise. When nothing holds any word, a NOTE says that this is not proof that no constraint applies, so read `get-context` for the Context being changed.

### `upsert-candidate`

*Add or revise a candidate.*

`upsert-candidate --registry-root <path> --repo-root <repo> --asset <asset> --record-file <file> [--record-file <file> ...]`

Validates a staged complete Registry and applies a recoverable update. Several record files are validated together and written in one update, so records that refer to each other can be added at once, and it says how many it created and how many it updated. A record whose cited excerpts are all among another record's of the asset, or the other way round, is noted as a possible duplicate, by the same test that marks `copied_evidence`. A citation with a path and lines but no digest gets the digests `cite` would give.

### `harvest`

*Prove and package harvested rules.*

`harvest --registry-root <root> --repo-root <repo> --spec <file> [--changes-root <dir>] [--through draft|verified]`

One call per harvest from `--spec`, whose format is below. It first cites the enforcing lines and the test function (a test the named file does not define is refused with the file and line that does define it), refusing by path a citation outside the confirmed sources (when today's discovery would place that path in a group the source map's listing does not yet hold, the refusal names the group and the `refresh-listing` to run, with the roots shown relative to the repository, and `next` leads with that command), then runs every counterfactual as one suite, and writes nothing unless each citation holds and each counterfactual is `killed` (`stopped_at` is `spec`, `citation` or `counterfactual` and `package` is null). It then writes each rule as a candidate, or marks a reviewed one `amended`, or `reproven` when only the proof is new, in both cases promoting the spec's statement, examples, contexts and freshly cited lines in place of the reviewed record's, and builds the package under `<changes-root>/<name>`. `--through verified` goes on to submit, record each obligation's test result, record the approval and verify, stopping `tested` with the next step named when the spec has no approval. The report lists each rule's verdict, record outcome and test citation, `package`, `written`, `resumed`, `stopped_at`, `errors` and `next`, for a refusal as for a success; it exits 1 when a stage left errors. A directory holding something other than this spec's package is refused before any counterfactual runs (`stopped_at` `package`), and so is this spec's package once it is past `submitted`. A step that fails after the package is written is reported, not thrown: `written` is true, `stopped_at` is `draft`, `submitted` (test results pending), `tested` (every result recorded, approval or verification pending) or `verified`, and `next` names the resume. Running the same spec again over its own `draft` or `submitted` package resumes it with `resumed` true; a submitted package whose rules changed since is refused.

#### The harvest spec

`harvest --spec` reads one JSON object that names the package and its rules.

The package:

- `name`, also the requirement and proposal id, `context`, `proposer`, `intent`, `outcome` and `scope`;
- the `ownership`, `boundary` and `design` decisions;
- an optional `approval` with `role` and `reviewer`.

Each entry of `rules`:

- `id`, `statement`, and `example` or `examples`;
- `enforcing` spans, each `path:start-end`, citing what enforces the rule, the code, a migration's constraint or trigger, or a contract, in any confirmed source; the decision or requirement that states the rule is evidence of its statement, not of its enforcement, so it is cited beside the enforcing lines, not in their place;
- the proving test as `test_file` and `test`, and the full `check` that runs it with an optional `cwd`, `command_profile` and `level`;
- `mutate`, with `file`, `find`, `replace` and an optional `expect`.

#### What a harvest writes

Each rule is written as a candidate, or a reviewed one is marked `amended`, or `reproven` when its statement, examples, contexts and cited spans are unchanged and only the proof is new, so the package supersedes its reviewer. The package starts under `<changes-root>/<name>`; a candidate is promoted as it stands, and an amended or reproven rule is promoted with the spec's statement, examples, contexts and citations, each cited afresh from the lines as they are now, in place of what the reviewed record held, so no stale citation survives into the package; then the package is filled and previewed `--as-status submitted`.

Filling writes one acceptance criterion `enforced-<id>` and one test obligation `rule-<id>` per rule, the obligation covering the rule through `also_covers` and running the rule's check. It replaces the criteria, obligations, `rule_ids`, `affected_contexts`, `proof_obligations`, the sources (every file the rules cite) and the evidence's `counterfactual_check` list from the counterfactuals it ran, each naming the file and protection it mutated, so the proof's subject is on record even where the rule's evidence cites other lines and the spec's decisions.

#### Resuming a harvest

A resume over the spec's own `draft` or `submitted` package skips what is already done:

- a draft record whose content is what the run would write is not written again and is reported `unchanged`;
- a rule already in the package is not promoted again;
- the fill is written only when it differs;
- a submitted package is not submitted again;
- an obligation with a passing result of its check is not run again;
- an approval by the same role and reviewer is not recorded again.

### `discard-harvest`

*Withdraw a Change Package that is not applied, written by harvest or by hand.*

`discard-harvest (--package-root <path> | --spec <file> [--changes-root <dir>]) --registry-root <root> --repo-root <repo> --reason <text>`

Withdraws a Change Package that is not applied, whether `harvest` wrote it or it was written by hand with `init-change-package`, such as a submitted package whose citations a refactor moved. With `--spec` the package is the one `harvest` writes for that spec, under `--changes-root` or the Registry's `changes/`, so the pair takes the same arguments; exactly one of `--package-root` and `--spec` is given. Refuses a package whose proposal is not `draft`, `submitted` or `verified`, and a directory with no package, so a verified harvest that will not be shipped is undone the same way, and `harvest` names this command, with the package path, when it refuses to re-run a verified harvest. Retracts, as `retract-candidate` does and with the reason, each record the package's `registry_updates` name that is still a candidate, except one that another package beside it, not superseded, also names; a reviewed record is left alone. Then removes the package directory and appends one `discard-harvest` audit event with the package path, the `retracted` and `kept` records and the reason, and prints it.

### `retract-candidate`

*Withdraw a candidate.*

`retract-candidate --registry-root <path> --repo-root <repo> --asset <asset> --id <id> [--id <id> ...] --reason <text>`

Removes the candidates `--id` names, all of one asset, in one Registry update with one audit event that lists their ids and the reason. It refuses a reviewed record, which is withdrawn through a superseding proposal instead, a record the rest of the Registry still references, and an id the Registry does not hold; when any is refused, none is removed.

### `promote-candidate`

*Put a candidate into a draft proposal.*

`promote-candidate --package-root <path> --registry-root <path> --asset <asset> --id <id> [--amend] [--repo-root <repo> (--cite <path>:<start>-<end> | --cite-function <path>:<name>) ...] [--drop-cite <path>:<start>-<end> ...]`

Copies the candidate record, without its review fields, into the draft proposal's `registry_updates` as an upsert; promoting the same record again replaces its entry and keeps the citations `--cite` added to it earlier. The Contexts the record names are added to the proposal's `affected_contexts`. It refuses a record the Registry does not hold, a reviewed record, and a proposal that is no longer a draft. With `--amend` a reviewed record is copied the same way and the proposal that last reviewed it, read from the audit log, is added to `supersedes`, so a rule can be re-proven or changed by editing its entry, such as adding the citation of the test that proves it; it refuses a reviewed record no applied package reviewed. `--cite` and `--cite-function`, each repeatable, add citations built as `cite` builds them to the promoted record's evidence; one naming lines the record already cites replaces that citation in place, so a stale citation is refreshed by citing it again and re-proving a rule needs no hand edit. `--drop-cite`, repeatable, removes the citation of exactly those lines from the promoted record's evidence, so an amendment can let go of lines the code no longer holds; it refuses lines the record does not cite.

### `init-change-package`

*Start a Change Package.*

`init-change-package --output <path> [--requirement-id <id>] [--proposal-id <id>] [--proposer <identity>]`, or, to package a re-citation, `init-change-package --output <path> --recitation <file> --registry-root <root> --requirement-id <id> --proposal-id <id> --proposer <identity>`

Writes the requirement, proposal, obligation, and evidence templates a material change is reviewed through. Given the identifiers, it writes them into every file that carries them, so they never have to be copied by hand. Without them it prints the flags still blank, which `validate-change-package` will ask for. It refuses a proposal id that a package beside the output already carries, and a package it fails to finish is removed. With `--recitation` it takes what `recite` or `relocate-evidence` printed and writes a complete routine package: its `registry_updates` and `supersedes`, the affected Contexts the records name, a requirement that every citation is current, and one obligation whose `check` is the full `verify-evidence` command on the cited paths with `--package-root` pointing at the package itself, so it passes before the package is applied, ready to pass to `record-test-result --command`. Refused when any update changes a record beyond its citations, removes one, or when the file still carries candidates or unmatched citations, because then the change is not a re-citation. Review, approval and attestation run as for any package.

### `validate-change-package`

*Validate a Change Package.*

`validate-change-package --package-root <path> --registry-root <path> [--repo-root <repo>] [--as-status <submitted|verified|approved|applied>]`

With `--repo-root`, a citation whose lines are unchanged but sit elsewhere in the file is a NOTE, one per record naming the files, not an error: it passes every check and the package applies as it is. Prints a NOTE when a counterfactual mutates a file the rules its obligation proves do not cite, since that proves the rule only when the mutated line lies on the execution path of a cited line. Requires each registry update to name a known asset, an obligation per acceptance criterion, rule, and contract, a named counterfactual check, and updates that reference existing assets; a Context, Rule or Contract the package itself adds counts as existing. Until the package is applied, it also validates the Registry as the updates would leave it and reports each new error prefixed `once applied:`, and each promoted record that cites a path outside the confirmed sources, and with `--repo-root` it requires every citation in the updated records to be current and every file the ownership and boundary decisions cite as evidence to exist. A valid package with no `registry_updates` says so in a NOTE. An applied or superseded package is history: it is not checked against the Registry it has since been followed by. With `--as-status` it validates the package as if it had reached that stage and lists everything it still lacks there in one pass. Fields the stage's own command writes, such as `verified_at` or the base revision, are not asked for, and neither are approvals before `approved`, since they can be recorded only once the package is submitted; the success message says so. Run it before each transition instead of discovering the stage's requirements one refusal at a time.

### `recite`

*Re-cite one changed citation.*

`recite --registry-root <root> --repo-root <repo> --asset <asset> --id <id> --path <path> [--lines <start>[-<end>]] [--replace <path>:<start>-<end>] [--onto <file>]`

Read-only. Cites the given lines and puts the citation in place of the record's one citation of `path`, or of the citation `--replace` names when the record cites a file more than once or the code moved to another file. Without `--lines`, it re-cites the lines `--replace` names, which must be in `path`; that is the case where the code changed but kept its lines. The printed record carries no `verified`: `ship-package` keeps the record's own `verified` for a re-citation that records no approval, or stamps it from the approvals. Prints the same shape as `relocate-evidence`: a reviewed record as `registry_updates` with the proposal to supersede, any other record as a candidate. Use it when code changed in place and `relocate-evidence` reports the citation unmatched. `--onto` takes the JSON an earlier `relocate-evidence` or `recite` printed: the record is re-cited from its version there, its entry is replaced, the `supersedes` are merged, the `unmatched` item it resolves is dropped, and the whole file is printed again, so a record with one shifted and one stale citation ends up as one update. When the cited text also occurs elsewhere in the file, it prints a NOTE on stderr naming where, because such a citation cannot be told apart after the next edit; widen it to lines that occur once.

### `relocate-evidence`

*Re-cite evidence after a move.*

`relocate-evidence --registry-root <root> --repo-root <repo> --from <old path> --to <new path>`

Read-only. For every citation under `from`, a file or a directory, finds the cited lines under `to` by their excerpt digest and re-cites them there. A citation whose lines are still in its own file, at the same place or moved within it, is left alone, so splitting a file re-cites only what left it. It prints `registry_updates` for the reviewed records, ready for a Change Package, `supersedes` with the proposals that reviewed them, `candidates` for records not yet reviewed, to pass to `upsert-candidate`, and `unmatched` for each citation whose lines were found zero times or more than once, with `found`, to cite by hand. A Context whose `implementation_path` is `from`, lies under it, or ends `from` the way `boundary-impact` maps a file to it (the Registry holds `billing/orders`, `from` is `src/billing/orders`) is given its new path in the same output, the same trailing parts of `to`, as a registry update or a candidate by its status. `citations_in_place` counts the citations under `from` whose lines stayed in their own file; when nothing needed moving a NOTE says so, and when `to` holds no file a NOTE names the Contexts whose proposed path review would refuse.

### `submit-proposal`

*Submit for review.*

`submit-proposal --package-root <path> --registry-root <path> --repo-root <repo>`

Captures the exact Git HEAD and Registry digest before changing a valid draft to `submitted`. Refuses an obligation whose check runs `go test` without `-v` or `-json`, which `record-test-result` could not record, and a promoted record citing a path outside the confirmed sources, which `ship-package` would refuse to review, so the refusal comes before approval and the signed commit.

### `list-proposals`

*List the Change Packages.*

`list-proposals --changes-root <dir>`

Prints each package under the directory with its `proposal_id`, `status`, `last_changed_at` (the latest lifecycle timestamp, including a redraft and a supersession; `null` for a draft never submitted), number of `registry_updates` and `supersedes`, and a superseded proposal's `superseded_by`, with `superseded_by_unknown` when no package under the directory carries that id, `supersedes_unknown` listing the ids it supersedes that no package carries, such as deleted or mistyped ones, and `duplicate_proposal_id` on packages sharing an id, so a stale draft or an empty one is found without opening each.

### `supersede-proposal`

*Retire a proposal.*

`supersede-proposal --package-root <path> --reason <text> [--superseded-by <id>]`

Keeps the status the proposal died in, its reason, and its replacement, rather than editing it back to a draft. When no package beside it carries the `--superseded-by` id yet, a NOTE says to create it with `redraft-proposal`, and `validate` names the proposal until one does. It and `redraft-proposal` accept `--registry-root` and `--repo-root` so a script can pass the same flags to every lifecycle command, and use neither.

### `record-approval`

*Record human approval.*

`record-approval --package-root <path> --role <role> --reviewer <identity> --scope <scope> [--approved-at <ISO-8601>] [--registry-root <path>] [--repo-root <repo>]`

Takes `--registry-root` and `--repo-root` as the other steps of the flow do and reads neither. Rejects self-approval and duplicate approval for the same role and revision.

### `record-test-result`

*Record a test result.*

`record-test-result --package-root <path> --registry-root <root> --repo-root <repo> --obligation <id> --command-profile <profile> [--timeout <seconds>] [--cwd <directory>]`

Runs the obligation's `check` while the proposal is draft or submitted, from the repository root, or from `--cwd`, a directory inside the repository recorded as the result's `working_directory`, without a shell, split into arguments by POSIX quoting rules on every platform, so `^`, `|` and `$` reach the program unchanged and pipes, `&&` and `VAR=value` prefixes are not available; set environment variables before calling it, and quote a Windows path that holds backslashes. The command profile only labels the run and never expands into a command, so the check is the full invocation, such as `<path>/domain-memory verify-audit --registry-root <root>`, not a shorthand. It records it for that obligation only when it exits 0 and a test passed, with the digest of its full output, replacing any earlier result for the obligation. A run that passed no test writes nothing: `go test` without `-v` or `-json`, because it does not say which tests passed, or with every test skipped; output saying `[no tests to run]`; unittest that ran nothing or skipped every test; a pytest summary without `passed`. A failing run, a proposal past submitted, an unknown obligation, or a profile outside a non-empty `approved_command_profiles` writes nothing; an empty list approves any profile.

### `ship-package`

*Attest, finalize and apply a verified package.*

`ship-package --package-root <path> --registry-root <root> --repo-root <repo> [--commit <sha>]`

The tail of a review after its verification, in one call and in three steps, in order. With `--commit`, the `attest-signed-commit` step, for the `git-signed-commit` verifier, resolves the commit, checks that an authorized signer signed it and that it carries this proposal and revision, then writes `scm_attestation` from the proposal. The `finalize-proposal` step approves only a verified proposal whose required approval roles, externally verifiable SCM evidence, traceability and base revision still validate. The `apply-approved-updates` step, through a recoverable update, promotes new or candidate records and removes records the proposal names, a reviewed record only when the proposal supersedes the one that reviewed it; each promoted record has its citations classified against the selected sources, not the `source_kind` the author wrote, and one citing a path outside them is refused. Without `--commit` it starts at `finalize-proposal`, for a package whose `scm_attestation` an earlier run already wrote. It stops at the first step that refuses, names that step and its reason in `errors`, and reports the steps `completed`, the proposal's `status` afterwards and the `next` step for that status; exit 1 when a step refused. Running it again is safe: an `approved` proposal is only applied, an `applied` one gets `note` "already applied; nothing was written", a `next` that asks for nothing but the commit, and exit 0, and a `--commit` other than the attested one is refused before anything is written. It writes the package and the Registry, never git. Why a reviewed record may not cite outside the confirmed sources: [Proposal lifecycle](proposal-lifecycle.md).

### `verify-proposal`

*Verify test attestations.*

`verify-proposal --package-root <path> --registry-root <root> --repo-root <repo>`

Refuses, before anything is signed, an update that once applied would be reviewed by nobody: the proposal records no approval and either the Registry holds no verified record of it or the update changes more than its citations; a re-citation that records no approval is applied with the record's own `verified`, and anything more needs `record-approval`. Run on a verified, approved or applied Proposal it prints `already <status> at revision <n>; nothing was written` and exits 0. Promotes only a submitted Proposal that every required approval role has approved and that has a passing, digest-backed result for every obligation; approvals can be recorded only while it is submitted, so it names any role still missing. Record each result with `record-test-result`, or add one entry to `test_results` in `evidence-bundle.json` per obligation after its test has run: `obligation_id`, `status: "passed"`, `evidence` (the obligation's `check`, or an `https://` link to the CI run), a `command_profile` the policy approves, `exit_code: 0`, `output_sha256` (`sha256:` and 64 hex characters), and `finished_at` (ISO-8601). Approvals are written by `record-approval`, never by hand.

### `rebase-proposal`

*Restamp a stale proposal on the current Registry.*

`rebase-proposal --package-root <path> --registry-root <root> --repo-root <repo>`

For a `submitted`, `verified` or `approved` proposal that verify, finalize or apply refuses as stale; it asks the same stale check, so a commit on top that touches nothing the proposal names is not a reason to rebase. Stamps the proposal's `base_registry_revision` and the evidence bundle's `registry_revision` with the Registry as it is now, raises `proposal_revision` by one, so the approvals recorded so far stay as history and stop counting, removes `scm_attestation`, which names the old revision, and sets the status back to `submitted`, keeping the test results. Refuses a draft, applied or superseded proposal; a proposal whose base is current gets `note` `the proposal base is current; nothing was written`, the next step for its status, and exit 0. Writes only the package, never the Registry, appends no audit event, and prints the package, the new revision and base, how many approvals it retired, whether it removed an attestation, and the next steps: record-approval for each required role, verify-proposal, a new signed commit holding the package, then ship-package.

### `quality-gates`

*Find the repository's own checks.*

`quality-gates --repo-root <repo>`

Lists the lint, type, architecture, test, hook, and pipeline configuration it finds, each with its path, and counts the test files. A golangci-lint configuration with `depguard` settings is also an architecture gate, and each hook Git runs, read where `core.hooksPath` points, is a hook gate; a sample or a copy kept beside a hook is not. A hook the repository ships elsewhere, such as `.githooks/pre-push` before `core.hooksPath` points there, is a hook gate with `enabled: false`. A `go.mod` with a `_test.go` file beneath it is a `go-test` gate, each Taskfile task whose name starts with `lint`, `typecheck` or `test` is a `task:<name>` gate, and a pipeline gate names the file or directory it was found at. `standard` is `configured` when a lint, type, or architecture check is configured and `none` otherwise. It reads configuration; it does not read a threshold, run a check, or confirm that a pipeline runs what is configured.

### `counterfactual`

*Break one protection and restore it.*

`counterfactual --repo-root <repo> (--file <path> --find <text> --replace <text> --test-command <command> | --suite <json file>) [--timeout <seconds>] [--cwd <directory>] [--expect <regex>] [--obligation-id <id>]`

`--suite` runs the mutations of one JSON file holding `test_command`, `cwd`, `timeout`, `expect` and `mutations` at the top level and, in each entry of `mutations`, `file`, `find`, `replace`, `test_command`, `cwd`, `timeout`, `expect` and `obligation_id`, an entry inheriting the top-level values it leaves out. The output is `results`, one object per entry in order, and `summary` with the count of each verdict; an entry's refusal becomes its own `error` result with its `entry` number instead of ending the suite, and the exit code is the worst verdict's. The command runs first on the intact file and is refused when it does not pass, giving that run's failure lines with its tail as `failure_evidence`, its `failing_tests`, and `log_path`, a file holding the whole output. A command that passes while running no test is refused on the intact file and `inconclusive` on the broken one. The one occurrence of `--find` is then replaced; a text that occurs more than once is refused with the first ten lines it occurs on and how many more. The command runs again and the file is restored byte for byte whatever the run did; a restore that still fails is an error naming the copy to restore from. Every verdict carries a `reason`: `killed` exits 0, `survived` exits 1, `inconclusive` exits 2. `--expect` is a pattern of the failing assertion, so a verdict word such as `FAIL` or `passed` is refused; write `--expect=PATTERN` when the pattern starts with `-`. A killed run prints `counterfactual_check`, the object a Change Package's evidence records, naming `--obligation-id` or a placeholder to fill. With `--package-root` and `--obligation-id`, a killed run whose file was restored also records that object in the package's `evidence-bundle.json` and prints `recorded_in`: it replaces the run recorded for the same obligation, keeps the others as a list, and replaces a `not_applicable` entry. The package must be draft or submitted and the obligation must be in `test-obligations.json` and, when the design lists them, in its `proof_obligations`; these are checked before anything runs, and a refusal is an `error`. Any other verdict writes nothing and prints `not_recorded`; `--package-root` does not combine with `--suite`. Every refusal, including a failing intact run and a usage mistake such as an unknown option, prints JSON with `verdict` `error` and its `reason` and exits 3. How to read a result: [Checks on the code being written](#checks-on-the-code-being-written).

#### Checks on the code being written

`quality-gates` and `counterfactual` need no Registry. They answer two questions an Agent otherwise answers from memory, and gets wrong.

`counterfactual` runs the command the caller passes:

- in the repository root or `--cwd`, with the caller's permissions;
- like `record-test-result`, without a shell: the command is split by POSIX quoting rules, so a pipeline or several commands go in a script.

It refuses:

- text that is absent or occurs more than once;
- a file outside the repository;
- any repository in which an earlier run left a `.counterfactual-original` copy, because that file may still hold a mutation every later proof would run against.

Reading a result:

- Break a protection so the code still builds: in Go, `if ready && false {` keeps `ready` used where `if false {` would not compile. A broken file that does not build, such as an unused variable or import or a syntax error, is `inconclusive`.
- Two guards that cover each other each survive alone; each needs a test only it can satisfy.
- Read `failure_evidence` before trusting a `killed`: it starts with the output's failure lines, such as `--- FAIL:`, `FAIL:`, `ERROR:` or `panic:`, each with up to three lines indented under it, such as the assertion message, then its last part.
- `inconclusive` means the run did not finish in time, the broken code did not build (whatever `--expect` matches), or, with `--expect`, the failure does not match the pattern.
- `killed` means the tests failed on the broken file. `survived` means they still passed, so nothing protects that line; its `reason` says the change may not break the protection at all (an equivalent mutation), which to rule out before you write a test for it.
- A run that judges nothing can kill nothing: `go test` without `-v` or `-json`, a `go test -v` or `-json` run in which every test was skipped (the refusal counts them and quotes the first skip's message, such as a missing environment variable) or no test matched, a unittest run of 0 tests or every test skipped, and a pytest run in which nothing passed are refused on the intact file and `inconclusive` on the broken one.
- `failing_tests` names the tests that failed on the broken file, read from `go test -v` or `-json`, where a subtest is named by its top-level test, pytest and unittest output, so a broad test command answers which test proves the protection; it is empty for any other runner.
- A restore the system refuses is retried for a few seconds before it is an error.
- Every refusal exits 3 with the same JSON shape, so a script never takes a refusal for `survived` or a usage mistake for `inconclusive`.

## Advanced commands

### `discover-sources`

*Map repository sources.*

`discover-sources --repo-root <repo> [--output <file>] [--implementation-root <dir> ...] [--excluded-directory <name> ...] [--decision-root <dir> ...] [--boundary-marker <file> ...]`

Inventories instruction files (`AGENTS.md` at any depth, the file name every coding agent reads; a host's own instruction file is not an instruction source) and candidate decision, requirement, contract, boundary, implementation, and test paths without inferring domain facts. The implementation roots are `apps`, `src`, `services` and `packages`, and the database schema roots `db`, `database`, `migrations` and `schema`, since a constraint or trigger a migration declares enforces a rule as code does; decisions are looked for under `docs/adr`, `adr`, `docs/architecture` and `architecture`, and a `doc.go` under an implementation root marks a bounded context. A repository laid out otherwise names its own in the policy's `project_profile`: `implementation_roots` and `decision_roots` replace those lists, `boundary_markers` names the files that mark a boundary (`package-info.java`, `index.ts`), and `excluded_directories` adds names to the directories every walk skips. The four are given here and to `init-domain-memory` as the repeatable `--implementation-root`, `--excluded-directory`, `--decision-root` and `--boundary-marker`; `init-domain-memory` writes them into the policy, `amend-policy` changes them, and every later discovery, `readiness`, the source snapshots and `refresh-listing` read them from there. A policy without the section keeps the defaults, so nothing changes for a Registry that never named one. A root with `..` or a leading slash, or a marker holding a path separator, is refused by name.

### `init-domain-memory`

*Start a Registry from human choices: the entry point.*

`init-domain-memory --repo-root <repo> --output <path> --source <path> --storage-mode <mode> --data-classification <class> --review-mode <mode> --source-authority <identity> [--review-verifier <verifier>] [--review-trigger <trigger>] [--ci-requirement <requirement>] [--authorized-signer <identity> ...] [--distinct-signer] [--include <glob>] [--exclude <glob>] [--implementation-root <dir> ...] [--excluded-directory <name> ...] [--decision-root <dir> ...] [--boundary-marker <file> ...]`

Requires an explicit destination and source choices. Applies include/exclude and policy resource limits before writing the confirmed map. `--distinct-signer` writes `review_governance.distinct_signer` as true, the two-person rule described under [Preparing the approval authority](#preparing-the-approval-authority); the profile flags are those of `discover-sources` and land in `project_profile`.

### `refine-sources`

*Focus selected sources.*

`refine-sources --registry-root <root> --repo-root <repo> (--source <path>... | --add <path>... --remove <path>...)`

Replaces a broad source corpus with focused paths, rebuilds snapshots, and resets selection to agent-asserted until a developer confirms it. `--source` gives the whole selection; `--add` and `--remove` change the current one and leave the rest selected, refusing to remove a path that is not selected.

### `recover-registry-update`

*Recover an interrupted update.*

`recover-registry-update --registry-root <path> [--repo-root <repo>] [--force]`

Uses the phase journal and matching audit operation to roll back or complete a transaction, and says whether there was one; `--force` is required only after confirming that a crashed writer left its lock behind. With `--repo-root` it also reconciles a pending apply: the audit log is the commit record, so a proposal it holds an apply for is marked applied, and a proposal it holds none for left the Registry unchanged and its marker is cleared, whatever the proposal's status. Without `--repo-root`, a pending apply that remains is an error.

### `export`

*Read the whole Registry from another tool.*

`export --registry-root <path> [--repo-root <repo> --commit <sha>]`

Prints every asset document as one JSON object keyed by asset name, as the working tree holds it or, with `--commit`, as that commit does. Read the Registry through this command, not its files: the files are the plugin's storage, and their layout may change.

### `change-coupling`

*See which modules change together.*

`change-coupling --repo-root <repo> [--root <path> ...] [--depth <n>] [--since <date>] [--exclude-subject <regex> ...] [--registry-root <root>] [--min-revisions 5] [--min-shared 5] [--min-degree 30] [--max-changeset 30] [--max-modules <n>]`

Reads the non-merge history and groups each changed file into the module `--depth` directories below the first `--root` that holds it (default `.` and 2), leaving out files directly in a root, files outside every root and modules that no longer exist. For each pair of modules it prints the commits they share and the degree, shared commits as a percentage of their average revisions, keeping a pair when both modules have `--min-revisions`, they share `--min-shared` commits and the degree reaches `--min-degree`; each pair lists the `subjects` of up to ten of its newest shared commits. A commit touching more than `--max-changeset` files under the roots is skipped and counted, and the newest twenty are listed in `skipped_large` with their `sha`, `subject`, number of `files` and `files_under_roots`. With `--max-modules`, a commit touching more modules than that is skipped and counted in `skipped_sweeping_commits`, and the newest twenty are listed in `skipped_sweeping` with their `sha`, `subject`, the `modules` counted and, with `--registry-root`, their `contexts`; with `--registry-root` only modules a Context owns count toward it. A commit whose subject matches an `--exclude-subject` pattern is left out and counted in `excluded_commits`. With `--registry-root` each pair names the `contexts` whose `implementation_path` each module lies in, or `null` for code no Context owns, and `explained_by`: `contexts/<id>` when both modules lie in one Context, the interactions, contracts and dependency policies registered between their two Contexts, or nothing, so an empty list is the coupling the Registry does not account for. When a module lies in no Context, `explained_by` is `null` and `unmapped` names that module. Why the skips exist and how to read them: [From code](extraction.md#from-code).

### `compare-registry`

*Score an extracted Registry.*

`compare-registry --gold-root <path> [--repo-root <repo> --gold-commit <sha>] --candidate-root <path> [--context <gold id> ...]`

Pairs each candidate record with at most one gold record and prints, per asset and overall, the pairs, the gold records missed, the candidate records with no counterpart, and precision, recall and F1. `--context`, repeated, scores only the gold records of those Contexts: the Contexts themselves and the records naming one. A Context the gold Registry lacks is refused, and `scope.without_candidate` names each scoped Context no candidate Context paired with, whose records therefore cannot pair. Each `overall_*` score carries its `matched`, `gold` and `candidate` counts. `overall_attempted` scores only the assets both Registries hold records of, and is `null` when there are none; `overall_independent` scores the same assets with each `copied_evidence` pair left out of both sides, `copied_matches` counts those pairs, and a NOTE says so when they are more than half the matches. A pair other than a Context pair is marked `copied_evidence` when one side's cited files and excerpts are all among the other's. A score is `null` when its denominator is zero. `possible_pairs` lists each missed gold record whose wording shares at least a quarter of its words with an extra candidate in a paired Context, with the `similarity`, for a person to confirm. A Context pairs by its `implementation_path`: the same path (`path`), one ending with the other, as when one Registry writes it from the repository root and the other from a module (`path-suffix`), or one inside the other (`nested-path`); otherwise by name. Interactions and dependency policies pair when both of their Contexts pair. Any other record pairs by id or name, ignoring case and punctuation (a term also by a gold synonym, an aggregate by its root), or by naming a paired Context and citing a file the gold record cites; among those, the pair whose cited lines overlap most is taken first. How to read the score: [From code](extraction.md#from-code).

### `confirm-sources`

*Confirm the selected sources.*

`confirm-sources --registry-root <root> --repo-root <repo> --confirmed-by <identity>`

Moves the source map from `agent-asserted` to `developer-confirmed`, recording who and when in the audit chain. Refused without a named developer, and refused once the sources have moved.

### `harvest-candidates`

*Harvest a scratch extraction.*

`harvest-candidates --registry-root <root> --repo-root <repo> --from-root <scratch root> [--context-map <candidate>=<gold> ...] [--keep-duplicates]`

Writes every record of a Registry extracted elsewhere, such as a blind extraction, into this one as candidates, in one update. It pairs the scratch Contexts with this Registry's the way `compare-registry` does, by `implementation_path` or name, and `--context-map` adds or overrides a pairing; a paired Context is not written, and every record naming it is written under the Context it paired with. A record whose id is reviewed here is skipped and listed in `skipped_reviewed`, and one citing exactly the excerpts of a reviewed record is skipped as a copy and listed in `skipped_duplicate` unless `--keep-duplicates`; citations without a digest get one. It prints the renames in `context_map`, every pairing in `context_pairs` with how it paired, `context_id_collisions` for a Context that pairs with the one of the same id here only by that id, not by path, what it `harvested`, `created` and `updated`, the files outside the confirmed sources, and `possible_duplicates`, reviewed or candidate records whose cited excerpts contain or are contained in a harvested record's.

### `redraft-proposal`

*Redraft a retired proposal.*

`redraft-proposal --package-root <superseded> --output <path> --proposal-id <id>`

Copies a superseded package into an empty directory as a draft under a new id: every lifecycle field returns to its template value and the superseded fields are dropped, while the requirement, design, and obligations carry over. Test results, the counterfactual check and the other recorded checks are reset, because they proved the superseded proposal, not this one. The draft lists the superseded proposal in `supersedes` and records `redrafted_at`. Like `init-change-package` it refuses a proposal id a package beside the output carries, and leaves the output as it found it when it fails. It refuses a proposal that is not superseded.

### `audit-attestations`

*Audit past attestations.*

`audit-attestations --repo-root <repo> --changes-root <dir>`

Re-checks every approved or applied package under the directory and reports each as `carried`, `not carried` (the attested commit exists and lacks this proposal, or there is none), or `unconfirmed` (the commit is not in this clone). It exits non-zero unless every package is `carried`, so an unconfirmed package is never counted as sound.

### `governance-readiness`

*Report what governance still needs.*

`governance-readiness --registry-root <path> --repo-root <repo>`

Names the missing pieces: no authorized signer, or no pre-push hook on this machine. A `local-draft-only` Registry reports working memory and needs nothing.

### `init-signing-key`

*Prepare a signing identity.*

`init-signing-key --repo-root <repo> --principal <identity> [--key-file <path>] [--force] [--sign-every-commit]`

Creates or adopts an ed25519 key with OpenSSH's `ssh-keygen`, the one external program besides `git` that any command needs, writes the allowed-signers file the verifier reads, points Git at both by setting `gpg.format`, `user.signingkey` and `gpg.ssh.allowedSignersFile` in the repository's Git config (`commit.gpgsign` too with `--sign-every-commit`), lists the keys it set under `git_config`, and reports the principal and fingerprint to authorize. It prints no private key material. When `DOMAIN_MEMORY_SIGNING_KEY` holds an OpenSSH private key it adopts that instead of generating one, so a container receives the identity as a secret; material it cannot derive a public key from is refused and the partial file removed.

### `amend-policy`

*Change governance fields.*

`amend-policy --registry-root <path> --set <field>=<value> [--set <field>=<value> ...] --reason <text> [--verifier <verifier>]`

Refuses a policy the validator rejects before writing, and appends the old value, new value, and reason of each field to the audit chain. Fields set together are applied as one change: only the final policy is validated, it is written once, and approvals go stale once, so a review mode and its verifier, trigger, and CI requirement move in one command. When `--set review_verifier=<verifier>` is among them, it serves as the verifier for leaving `local-draft-only`. Leaving `local-draft-only` requires `--verifier`, because a review mode and the authority behind it move together. `authorized_signers` takes a comma-separated list, so a lost key can be rotated out; `distinct_signer` takes `true` or `false`; `implementation_roots`, `excluded_directories`, `decision_roots` and `boundary_markers` take comma-separated lists and amend the `project_profile`, which is created when the policy has none. Selected source paths and limits are settled at initialization and are not amendable.

### `install-git-hitl-hook`

*Enforce signatures on push.*

`install-git-hitl-hook --registry-root <path> --repo-root <repo>`

Installs a pre-push hook in the directory Git actually runs, preserving any existing hook beside it and running that first. It checks every pushed commit that touches the Registry, running the `domain-memory` executable committed for the machine's platform, or `engine/target/release/domain-memory` elsewhere, and refuses the push when that executable is missing. The hook looks for the executable in this order: `git config domain-memory.executable`, a path from the repository's top level or an absolute one; the executable committed in the plugin that installed it; then `domain-memory` on PATH. `git config domain-memory.install-hint <text>` replaces the instruction a missing executable prints. An executable installed outside a plugin's `engine/` directory, such as one from a release, writes no engine path into the hook and records its own path as `domain-memory.executable` when the clone names none, saying so: relative to the repository's top when it sits inside it, because the key is shared by every worktree of the clone. `--executable <path>` records exactly the path given instead, on either install command. Both hooks read git config on every run, so moving the install needs no new hook; so does `domain-memory.git-timeout`, which they export as `DOMAIN_MEMORY_GIT_TIMEOUT` when the environment does not set it.

### `install-pre-commit-hook`

*Check staged citations on commit.*

`install-pre-commit-hook --registry-root <path> --repo-root <repo>`

Installs a pre-commit hook in the directory Git actually runs, preserving any existing hook beside it and running that first; a second install replaces only its own hook. On each commit it lists the staged added, copied, modified, renamed and deleted files, a rename or copy with both its old and its new path. When none of those paths is named as a citation or source path in the Registry's `registry/` directory or its `source-map.json` it stops there without running the executable. Otherwise it runs `verify-evidence --staged` with each of those paths as `--path` and refuses the commit when any citation of them is `stale`, `missing`, `unhashed` or `invalid`. It prints one line per failing citation that names the record and the cited lines, one more line per rename in the commit naming the `relocate-evidence --from <old> --to <new>` that moves its citations, then the command that prints the full report; the JSON report itself goes to standard error only when the environment variable `DOMAIN_MEMORY_HOOK_VERBOSE` is set. Once that passes, and when `HEAD` exists, it prints the `boundary-impact --base HEAD` verdict as a `NOTE:` on standard error unless it is `no-cross-context-change`; the note never refuses a commit. Like the pre-push hook, `--no-verify` skips it.

- A path mentioned only in prose or in a Change Package does not count as a citation or source path, so the hook stops at its first check for it.
- The hook refuses on `missing` as well as `stale`, so deleting a cited file, or renaming it to a name nothing cites, stops the commit like a weakened line does; the line for a `missing` citation says the path is not in this commit and points at `relocate-evidence`.
- It checks the staged content, so a file staged in part, or restored on disk after staging, is checked as the commit will hold it.
- The hook it chains to is found through Git at run time, so it runs from a linked worktree too; the pre-push hook finds its chained hook the same way.
- Where `core.hooksPath` names a tracked directory, the installed hook is a committed file that changes every clone's commits, so installing it there is a decision for the repository owner, not a local convenience.

### `verify-git-governance`

*Check commit signatures.*

`verify-git-governance --registry-root <path> --repo-root <repo> (--commit <sha> | --stdin)`

Requires each commit, given by `--commit` or one per line on standard input with `--stdin`, to carry a valid signature whose principal or key fingerprint is authorized by the policy and to change Registry files. Prints one line for the whole set; an error names the commit it is about. The pre-push hook passes a push's Registry commits in one call. It checks signatures, not `distinct_signer`, which applies where a proposal is attested and finalized. Like `validate`, it notes the approved Change Packages not applied yet.

### `validate-policy`

*Check a policy before adopting it.*

`validate-policy --policy <file>`

Reports every reason a policy would be refused, including a review mode and verifier that contradict each other.

### `verify-scm-attestation`

*Check SCM evidence alone.*

`verify-scm-attestation --attestation <file> --package-root <path>`

Checks a single attestation against its proposal without finalizing anything.

### `demote-local-reviews`

*Withdraw local reviewed status.*

`demote-local-reviews --registry-root <path> --repo-root <repo>`

Returns every reviewed record to candidate and strips its review metadata. Only a `local-draft-only` Registry accepts it: it is how a Registry retracts approvals that turned out not to be externally verifiable.

### `refresh-sources`

*Re-snapshot the selected sources.*

`refresh-sources --registry-root <path> --repo-root <repo>`

Rebuilds the snapshots of the paths already selected and returns the selection to agent-asserted, so a developer confirms the sources again before they back reviewed records. It prints `Selection reset to agent-asserted; confirm these N selected sources: <paths>`: the paths are the selected sources whose confirmation was reset, not files that changed.

### `refresh-listing`

*Refresh the discovered listing.*

`refresh-listing --registry-root <path> --repo-root <repo>`

Rewrites only the discovery listing the source map keeps, `source_groups` and the `missing_groups` derived from it, so it adds the paths discovery would place in a group today and drops those it no longer finds. The selected paths, snapshots, `selection_status`, `confirmed_by`, `confirmed_at`, the policy report and every other key stay as they were, so a confirmed selection stays confirmed. It refuses and writes nothing unless the selection itself verifies as `current` (an edit inside a selected file is `content_changed`, leaves the selection current and does not refuse, since every cited span carries its own hash), printing `ERROR: the selection is <status>: <reason>; run refresh-sources, then confirm-sources` and exiting 1. With no drift it writes nothing and prints `Listing already current`; otherwise it appends an `added`/`removed` event to the audit log and prints `Listing refreshed: +N -M discovered paths` followed by an `added:` line and a `removed:` line naming the paths, each only when non-empty.

### `scan-secrets`

*Scan for secrets.*

`scan-secrets --repo-root <repo>`

Reports findings, skipped paths, and how much was read. Inside a repository it reads the files git tracks or would add, so an ignored path such as a virtual environment or a build cache is never read; outside one it walks the directory. A file whose first 8 KiB holds a NUL byte is binary and is read no further. Exit 1 means it found something, whether or not the scan was complete. Exit 2 means it found nothing but the scan was incomplete, so its silence proves nothing. The `generic-secret` kind takes a quoted literal or a bare value after a secret-sounding name; a call, a member access or an index on the right-hand side is code, not a value.

### `mcp-serve`

*Serve the read commands to a host over MCP.*

`mcp-serve --registry-root <root> --repo-root <repo>`

Runs a Model Context Protocol server on standard input and output, one JSON-RPC message per line, until its input closes. It offers thirteen read commands as tools, named with `_` for `-`: `get_context`, `get_record`, `resolve_terms`, `lookup`, `dependents`, `coverage`, `brief`, `boundary_impact`, `verify_evidence`, `validate`, `readiness`, `list_proposals` and `validate_change_package`. Each takes the command's own options as arguments, such as `id`, `asset`, `base`, `markdown` or `path`, and returns what the command prints as text, with its NOTEs as a second text. When the command succeeds and prints a JSON object, the result also carries that object as `structuredContent`; `get_context`, `get_record`, `dependents`, `coverage`, `boundary_impact`, `verify_evidence` and `readiness` always print one and declare an object `outputSchema`, while a list, Markdown or a plain line comes back as text only. No command that writes is offered. The Registry and the repository are the server's own arguments, never the client's, and a path argument, `changes_root` or `package_root`, is read relative to the repository and refused outside it. A refusal, a usage mistake, a required argument left out (named as the JSON argument, such as `get_context: argument id is required`), an argument the command does not take and a non-zero exit come back as a result with `isError`; an unknown tool or method, a malformed line and an unsupported protocol version as a JSON-RPC error. It answers the `initialize` handshake of the protocol versions from 2024-11-05 to 2025-11-25 and the per-request `_meta` of 2026-07-28 with `server/discover`. Nothing but replies reaches stdout.

Register it as a stdio server, with the executable for the platform:

```json
{"command": "<plugin>/engine/bin/linux-x86_64/domain-memory", "args": ["mcp-serve", "--registry-root", "<root>", "--repo-root", "<repo>"]}
```

### `validate-contract`

*Check a contract schema file.*

`validate-contract --schema <file>`

Parses a local JSON schema file and reports `valid`, `invalid`, `missing`, or `unverified`; only `valid` exits 0. A contract it cannot parse locally is `unverified` rather than valid, because the command does not claim a result it did not compute.

## Preparing the approval authority

A Registry initialized as `local-draft-only` produces candidates and nothing else; no command promotes a record until the policy names an authority that can be checked from outside the package. One verifier does that, `git-signed-commit`, and `discover-sources` recommends it with the `git-push` trigger for every repository, whatever CI it lists: the maintainer or a reviewer signs the commit that carries the change, and the signature is the evidence. Git verifies it offline in every clone, against the policy's `authorized_signers` and the allowed-signers file, so no hosting provider, token or network call takes part, and a repository on any host, or on none, is governed the same way. That commit must add this Change Package with the same `proposal_id` and `proposal_revision`, so a signature on an earlier commit cannot stand in for this proposal's review; its `scm_attestation` is written by `ship-package --commit`, in the shape of [scm-attestation.json](../templates/scm-attestation.json).

With `distinct_signer` true in the policy, the signer must be someone other than the commit's author: `ship-package` reads the author's email and the signer's principal from git and refuses a commit its author signed, which is the two-person rule of a source-integrity standard applied with git alone. The comparison uses the principal the allowed-signers file gives the key, so list each key under its owner's email there. A repository where one person both writes and approves leaves it false, the default.

Authorize a key by its fingerprint rather than its principal when the address it was created under may change. Both are reported by `init-signing-key` and either satisfies the check.

## Output and refusals

Output follows three cases:

- A command that answers a question (`lookup`, `get-context`, `export`, `verify-evidence`, `quality-gates` and the other reads) prints JSON on stdout, except `probe`, which prints one sentence, and `brief --markdown`, which prints Markdown. `validate`, `validate-policy`, `validate-change-package`, `verify-scm-attestation` and `verify-git-governance` print their verdict on stdout, or one `ERROR:` line per problem on stderr.
- A command that writes (`upsert-candidate`, `submit-proposal`, `init-domain-memory` and the other changes) prints what it did as text on stdout, except `harvest`, `harvest-candidates`, `discard-harvest`, `rebase-proposal`, `ship-package`, `discover-sources` and `init-signing-key`, which print JSON. A refused step of `harvest` or `ship-package` sits in its report's `errors`, and the command exits 1.
- Every other refusal prints `ERROR: <reason>` on stderr and exits 1, so stdout carries only the command's output.

Three things fall outside these cases: a refused `counterfactual` prints JSON and exits 3, because 1 means `survived` and 2 `inconclusive`; a usage mistake, such as an unknown option or an empty query, exits 2 with argparse's message on stderr, and `probe` also exits 2, with its sentence on stdout, when the root holds no source map; and every `NOTE:` goes to stderr. Output is UTF-8 with line feeds on every platform, and a path a report shows, such as a package outside the repository, is a posix path on every platform.

The commands that walk the repository — `discover-sources`, `readiness`, `quality-gates`, and the snapshots behind `confirm-sources`, `refresh-sources` and `verify-sources` — skip what is not the repository's own source. That means every directory named `.git`, `.hg`, `.svn`, `node_modules`, `.venv`, `vendor`, `dist`, `build` or `generated`, every name the policy's `project_profile` adds in `excluded_directories` (`quality-gates`, `cite --function` and the sidecar check of `counterfactual`, which run without a policy at hand, skip the built-in names only), and every path Git ignores. Discovery, `readiness` and `quality-gates` also skip a nested checkout (a directory holding its own `.git`), and snapshots skip symbolic links. `quality-gates` further leaves configuration inside `fixtures`, `__fixtures__` and `testdata` out of its gates and its test count. Only names inside the repository count, so a repository checked out under a directory called `build` is walked normally. Every git and ssh-keygen call gives up after 15 seconds, or after the number of seconds in `DOMAIN_MEMORY_GIT_TIMEOUT`; the limit is per call, so a command that runs git several times can wait several times that. The refusal names the variable and, when the command had written nothing, says that running it again is safe. On timeout the whole process tree the call started is stopped, through a job object on Windows and the process group elsewhere. A hook the plugin installs exports `git config domain-memory.git-timeout` as that variable when the environment does not set it, so a slow machine sets the limit once with `git config --global domain-memory.git-timeout 60`.

A left-out `--repo-root` is the top level of the git repository the command runs in, and a left-out `--registry-root` is the one Domain Memory that repository holds, found the way `readiness` finds it: a command refuses, naming them, when the repository holds none or several, or when it runs outside a git repository; an explicit flag always wins. `verify-sources` finds a left-out `--source-map` the same way, as `source-map.json` in that Domain Memory, and then checks the policy beside it when there is one. `readiness`, `cite`, `change-coupling` and the Change Package commands whose `--registry-root` or `--repo-root` was already optional keep their own meaning for a left-out root. The scripts do not grant authorization: call a write command only when the current user and repository process authorize it.

## The shape of an update

An update in a Change Package:

- Include `registry_updates` in `domain-change-proposal.json`. Each update names an asset and uses `operation: "upsert"` with the complete record, or `operation: "remove"` with the `id` of a record the Registry holds.
- `verify-proposal` validates submitted test results as attestations; it does not run an arbitrary command from the package.

Removal:

- A removal is refused when no such record exists, so a mistyped id fails loudly instead of doing nothing.
- The staged Registry is validated before the update lands, so a record the rest of the Registry still references cannot be removed.

The base revision:

- Submission records a deterministic digest of all standard Registry files plus the observed Git HEAD when available, and, when that commit holds a Registry, the digest of the Registry it holds as `committed_digest`, from which a later check rebuilds the base.
- Verify, finalize and apply require that digest to remain current, or the records the proposal touches to be unchanged since it, as [proposal-lifecycle](proposal-lifecycle.md) describes.

Replacing a reviewed record:

- The apply command validates the Change Package, then rejects an update that would overwrite or remove a reviewed record unless the proposal's `supersedes`, one proposal id or a list of distinct ids, names the exact proposal that reviewed it; a package that replaces records reviewed by several proposals lists them all.
- Naming that approval is what makes the replacement governed: the replacing proposal still carries its own approvals and SCM evidence, and one that names a different proposal, or none, is refused.
- This is how a reviewed record follows a domain that changed; a record whose cited line moved is corrected this way, not left stale.
