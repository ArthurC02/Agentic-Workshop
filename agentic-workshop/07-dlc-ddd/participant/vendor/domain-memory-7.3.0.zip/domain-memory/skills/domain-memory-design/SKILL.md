---
name: domain-memory-design
description: Turn a material domain change into a reviewable boundary decision and Change Package. Use after Read, when the seven-step workflow says the change is material; it records unknowns instead of inventing facts.
license: MIT
compatibility: "Part of the Domain Memory plugin: needs git and the domain-memory executable the plugin bundles (Linux x86-64, macOS, Windows x86-64), and reads the plugin's shared references through ../../ links."
---

# Design a Domain Change

Use the read capability first. For a material change, follow [the seven-step workflow](../../references/seven-step-workflow.md), which defines what is material.

1. Start with business behavior and observable acceptance criteria.
2. Identify the owning Context and existing collaboration.
3. Choose the narrowest collaboration surface that preserves consistency, authorization, idempotency, failure, and observability behavior.
4. Derive the tactical design from the invariant and consistency boundary. First decide whether a tactical pattern is needed; then record the domain forces, smallest chosen approach, rejected alternatives, and proof obligations, prescribing no language-specific class or package layout. See [tactical design reasoning](../../references/tactical-reasoning.md).
5. Define the proof and counterfactual check with [pattern verification](../../references/pattern-verification.md). Create and validate the Requirement, Proposal, Test Obligations, Evidence Bundle, and Draft PR. The proposal's `implementation_design` is the [implementation handoff](../../references/implementation-handoff.md) for the coding Agent.

Do not turn an absent Registry record into an invented fact. A proposal records uncertainty and requires the configured review before implementation may rely on it.
