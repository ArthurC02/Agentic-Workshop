from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from .sources import (
    discover_ci_tools,
    file_name,
    ignored_relatives,
    repository_files,
    test_candidates,
)

FORMAT = "domain-memory-quality-gates/v1"
KINDS = ("lint", "types", "architecture", "tests", "hooks", "ci")
STANDARD_KINDS = {"lint", "types", "architecture"}

MARKER_FILES = {
    ".golangci.yml": ("lint", "golangci-lint"),
    ".golangci.yaml": ("lint", "golangci-lint"),
    "ruff.toml": ("lint", "ruff"),
    ".ruff.toml": ("lint", "ruff"),
    ".flake8": ("lint", "flake8"),
    ".pylintrc": ("lint", "pylint"),
    ".oxlintrc.json": ("lint", "oxlint"),
    "biome.json": ("lint", "biome"),
    ".rubocop.yml": ("lint", "rubocop"),
    "clippy.toml": ("lint", "clippy"),
    "checkstyle.xml": ("lint", "checkstyle"),
    ".shellcheckrc": ("lint", "shellcheck"),
    "tsconfig.json": ("types", "typescript"),
    "mypy.ini": ("types", "mypy"),
    "pyrightconfig.json": ("types", "pyright"),
    ".importlinter": ("architecture", "import-linter"),
    ".go-arch-lint.yml": ("architecture", "go-arch-lint"),
    "pytest.ini": ("tests", "pytest"),
    ".pre-commit-config.yaml": ("hooks", "pre-commit"),
    "lefthook.yml": ("hooks", "lefthook"),
}
MARKER_PREFIXES = {
    ".eslintrc": ("lint", "eslint"),
    "eslint.config.": ("lint", "eslint"),
    ".dependency-cruiser.": ("architecture", "dependency-cruiser"),
    "jest.config.": ("tests", "jest"),
    "vitest.config.": ("tests", "vitest"),
    "playwright.config.": ("tests", "playwright"),
}
PYPROJECT_TOOLS = {
    "ruff": "lint",
    "flake8": "lint",
    "pylint": "lint",
    "mypy": "types",
    "pyright": "types",
    "importlinter": "architecture",
    "pytest": "tests",
}
PACKAGE_SCRIPTS = {"lint": "lint", "typecheck": "types", "test": "tests"}
PYPROJECT_TABLE = re.compile(r"^\[tool\.([A-Za-z0-9_-]+)", re.MULTILINE)


def gate(kind: str, tool: str, path: str) -> dict[str, str]:
    return {"kind": kind, "tool": tool, "path": path}


def marker_for(name: str) -> tuple[str, str] | None:
    if name in MARKER_FILES:
        return MARKER_FILES[name]
    for prefix, marker in MARKER_PREFIXES.items():
        if name.startswith(prefix):
            return marker
    return None


def pyproject_gates(path: Path, shown: str) -> list[dict[str, str]]:
    try:
        tables = set(PYPROJECT_TABLE.findall(path.read_text(encoding="utf-8")))
    except UnicodeDecodeError:
        return []
    return [
        gate(kind, tool, shown)
        for tool, kind in PYPROJECT_TOOLS.items()
        if tool in tables
    ]


def package_gates(path: Path, shown: str) -> list[dict[str, str]]:
    try:
        scripts = json.loads(path.read_text(encoding="utf-8")).get("scripts", {})
    except (json.JSONDecodeError, UnicodeDecodeError, AttributeError):
        return []
    if not isinstance(scripts, dict):
        return []
    return [
        gate(kind, f"script:{name}", shown)
        for name, kind in PACKAGE_SCRIPTS.items()
        if name in scripts
    ]


FIXTURE_DIRECTORIES = {"fixtures", "__fixtures__", "testdata"}

CONTENT_READERS = {"pyproject.toml": pyproject_gates, "package.json": package_gates}


def in_fixture(entry: str) -> bool:
    return any(part in FIXTURE_DIRECTORIES for part in entry.split("/"))


def candidate_files(files: list[str]) -> list[str]:
    return sorted(
        entry for entry in files
        if (marker_for(file_name(entry)) or file_name(entry) in CONTENT_READERS) and not in_fixture(entry)
    )


def configured_gates(root: Path, candidates: list[str]) -> list[dict[str, str]]:
    gates = []
    for shown in candidates:
        name = file_name(shown)
        marker = marker_for(name)
        if marker:
            gates.append(gate(*marker, shown))
        if name in CONTENT_READERS:
            gates.extend(CONTENT_READERS[name](root / shown, shown))
    return gates


def quality_gates(repo_root: Path) -> dict[str, Any]:
    root = repo_root.resolve()
    if not root.is_dir():
        raise ValueError(f"repository root is not a directory: {repo_root}")
    files = repository_files(root)
    candidates, tests = candidate_files(files), test_candidates(files)
    ignored = ignored_relatives(root, candidates + tests)
    gates = configured_gates(root, [entry for entry in candidates if entry not in ignored])
    gates.extend(gate("ci", tool, "") for tool in discover_ci_tools(root))
    present = sorted({entry["kind"] for entry in gates})
    return {
        "format": FORMAT,
        "gates": gates,
        "kinds_present": present,
        "kinds_missing": [kind for kind in KINDS if kind not in present],
        "test_files": sum(entry not in ignored and not in_fixture(entry) for entry in tests),
        "standard": "configured" if STANDARD_KINDS & set(present) else "none",
    }
