---
name: domain-memory-maintain
description: Keep file-backed Domain Memory current after implementation or source changes by preserving evidence and creating governed candidate updates.
---

# Maintain Domain Memory

Use this after implementation and whenever a selected source moves.

For a brownfield refactoring that preserves the reviewed model, follow the [brownfield refactoring fast path](../../references/brownfield-refactoring.md) to decide whether a candidate is needed before creating one.

1. Run `verify-sources --repo-root <repo> --source-map <registry>/source-map.json --policy <registry>/domain-memory-policy.json`, `verify-evidence --registry-root <registry> --repo-root <repo>`, `verify-audit --registry-root <registry>`, and `boundary-impact --registry-root <registry> --repo-root <repo> --base <branch point>`, which names the Contexts the change touched together and the boundary records whose evidence changed. `<registry>` is the registry root, the directory that holds `registry/`, `source-map.json`, and the policy, not `registry/` itself.
2. Compare the implemented behavior with the reviewed terms, owner, invariants, boundaries, events, contracts, and capabilities.
3. Compare the implementation's tactical choice, including an explicit choice of no pattern, with the invariant, ownership, consistency, retry, and failure behavior it claims to preserve. Review behavior and dependencies, not a fixed language pattern. See [tactical design reasoning](../../references/tactical-reasoning.md).
   When deployment configuration affects an immutable record's behavior, verify that the chosen value is captured in that record's snapshot rather than reread during retries.
   For dispatch policy, snapshot every value that changes a compatibility or safety decision, including minimum isolation and any explicitly accepted provider limitation.
   Integration tests must construct adapters through the same composition wiring; do not retain Context-owned environment factories only for tests.
   Treat HTTP clients, transports, and timeouts as adapter composition concerns: inject them at the entrypoint and retain a focused seam test that proves the selected client reaches the adapter.
   For an internal capability call, keep the Context adapter responsible for its request and response contract, while wiring owns the endpoint credentials and HTTP client.
   When the use case supplies the request deadline through context, do not add a shorter client timeout in composition; test that the caller remains the single timeout authority.
   A test-friendly adapter fallback does not replace production composition; verify the executable entrypoint supplies the client explicitly.
   When an adapter depends on deployment posture, parse posture once at the entrypoint and pass the typed value to wiring instead of letting the adapter reread environment variables.
   Keep runtime setting types and their pure validation in Foundation, but place operating-system environment parsing only in entrypoint wiring.
   A reusable fallback helper must select between supplied values only; its caller at the command or wiring boundary owns reading the environment.
   If a framework-owned table cannot be represented by the application's query generator, confine its raw SQL to an entrypoint adapter and keep ownership metadata pointed at that exact adapter.
4. The model changed when any of these changed: a term, which Context owns a decision, an invariant or rule, a boundary or allowed dependency, an event or contract, or a capability. A change to who may decide a value, its bounds, or when it is decided is a rule change; moving a value from deployment configuration to a setting someone adjusts at run time is one. Moving or renaming code while all of these stay put is a refactor.
   If the model changed, update the smallest affected asset with `upsert-candidate`, or prepare a Change Package for a material change. For a boundary-preserving refactor, retain the focused architecture check when one exists; otherwise retain affected tests and lint as preservation evidence.
5. From the repository root, run `validate --registry-root <registry> --repo-root <repo>`, then preserve the audit trail.

For a material change, compare the implementation with its implementation handoff and run the counterfactual check described in [pattern verification](../../references/pattern-verification.md). Missing proof, a changed assumption, or a different consistency decision is a model discrepancy even when the unit tests are green.

Never hide a domain change in code-only edits. Candidates prepare the next review and do not authorize implementation. Use only the controlled file-backed commands; do not hand-edit reviewed records or policy. Read [registry maintenance](../../references/registry-maintenance.md).
