# Extraction

Extraction turns a source into Registry candidates. It is judged by one question per element: does the source show this element as DDD defines it? A technique only proposes candidates; the definition decides.

## What each element is

| Element | It exists when the source shows | It is not |
| --- | --- | --- |
| Bounded Context | a boundary inside which one model and its terms mean one thing, owned and changed together | a folder, a service, or a team name on its own |
| Term | a word the domain uses with one meaning inside a Context, tied to behavior | an identifier, a table, or an acronym |
| Rule | a falsifiable statement the system enforces or refuses to break | a test name, a log message, or a wish |
| Capability | a business ability one Context owns and others ask of it | a handler, a package, or a feature flag |
| Aggregate | one invariant that must hold across several objects in a single consistency boundary, guarded by one root | an entity, a table, or a class with children |
| Domain Event | a business occurrence the domain cares about, after it is committed | a technical notification or a state write |
| Value Object | an immutable concept compared by its values | any data structure without an ID |
| Contract | a promise between processes or Contexts: shape, version and compatibility | an endpoint or a topic name |
| Interaction | one Context reacting to or calling another, with its consistency and, when the code shows it, the Context Map relationship between them | an import edge |
| Dependency policy | a direction one Context's code may or must never depend on | an observed import |
| Decision | a current, owned choice that constrains the model | a discussion or a superseded choice |

When the source shows something close to an element but not its defining property, record nothing, or record the weaker element that the source does show.

## The order of work

Models find vocabulary and relations reliably and Bounded Contexts and Aggregates unreliably, and an early wrong boundary spreads into everything recorded after it. So start with the smallest slice that holds a real cross-Context behavior, two Contexts, a shared term, an invariant and one interaction, extract in this order, and validate after each stage before building on it:

1. **Language.** Collect the terms the domain uses and what the code or requirement does with each. A word with two meanings is a boundary signal, not one term. Keep them as notes: a Term names its Contexts, so it is recorded once step 2 has them.
2. **Boundaries.** Propose Contexts only where several signals agree: the language changes, data is owned and written in one place, changes land together, and calls cross the boundary through an explicit surface. Each Context names its `implementation_path` when code exists. Prefer fewer, evidenced Contexts to a speculative split.
3. **Relations.** Record Interactions and Contracts across the boundaries from step 2. When the work covers one Context and a relation needs a neighbour, record the neighbour as a candidate Context holding only what the evidence shows, such as its `id`, `name` and `implementation_path`, so the relation can name it; Review decides whether it holds. Record a Dependency policy only for a direction a check enforces or a decision states.
4. **Tactical facts.** Rules, Aggregates, Events and Value Objects, each inside one Context from step 2. A Rule that states an Aggregate's invariant and an Event that Aggregate raises name it in `aggregate`; an Event published under a Contract names it in `contract_id`.

## From a requirement

Read the intended behavior and its acceptance criteria. Resolve each noun with `resolve-terms` before inventing a term. Name the Context that would own the decision, the rules the criteria make falsifiable, the events the criteria observe, and the collaborations the behavior needs. Anything the requirement leaves open is an open question in the Change Package, not a guessed record; continue with the Design capability, `domain-memory-design`, for a material change.

## From code

Treat the code as the evidence of current behavior, not of intent. Read the boundary surfaces first: public APIs, event schemas, persistence ownership, composition roots and architecture checks. Then read inside each candidate Context for its terms, guards and refusals. Tests that assert a refusal are good evidence for a rule; a test name alone is not.

`change-coupling --repo-root <repo> --root <code root> --depth <n>` reports which modules change together in history.

- Strong coupling inside a candidate Context supports it; strong coupling across two candidates asks whether they are one Context or share a hidden contract; a composition root couples with everything and says nothing about boundaries.
- Use `--since` to keep a rewritten history from dominating, and `--exclude-subject` with a pattern such as `^(chore|style|test)` to leave out repository-wide sweeps, which couple modules that share no domain; `test(` subjects are often sweeps too.
- Read each pair's `subjects` to tell a domain change from a sweep, and each `skipped_sweeping` entry's `modules` and `contexts` to check that it was one. A feature that fans in, one Context consuming several others in one commit, also crosses `--max-modules`: run once without it before concluding that a hub Context has no visible collaborations.
- An empty `explained_by` is coupling the Registry does not account for; a `null` one is a module no Context owns, which the Registry cannot speak for.

`compare-registry` scores an extraction against a gold Registry. Reading the score:

- Score an extraction that covered part of the code with `--context`, so an extraction of other code does not lower the precision; the interactions and dependency policies between a scoped Context and another are still scored.
- A ratio over two records reads as such: look at the `matched`, `gold` and `candidate` counts beside each `overall_*` score.
- A `copied_evidence` pair usually cites the package documentation either side would cite, as when a harvest dropped a citation; `overall_independent` leaves those pairs out.
- It measures structure, not meaning: a rule worded differently but citing other lines counts as missed. Read `possible_pairs` and the missed and extra lists before trusting a number.

## From a change

Start from what moved: `boundary-impact --base <ref>` for the Contexts and evidence a change touched, `change-coupling --since <date>` for how the change pattern shifted, and the diff or the changed requirement itself. Then decide, element by element, whether the model changed: a term, the owner of a decision, an invariant or rule, a boundary or allowed dependency, an event or contract, or a capability. A change to who may decide a value, its bounds, or when it is decided is a rule change; moving a value from deployment configuration to a setting someone adjusts at run time is one. A refactoring that moves code and keeps all of these is not a model change; re-cite its evidence with `relocate-evidence` and record nothing new.

## What a record holds

Only the element, its relations and its evidence. Never the technique that found it, the steps taken, a confidence score, a session note or a to-do. Unresolved points belong in the Change Package's open questions. A shorter record that a reviewer can check against its citations is better than a complete-looking one that restates the source.
